from preprocessing.verification import verify_dataset
from preprocessing.duplicate_checker import check_duplicates
from preprocessing.duplicate_remover import remove_duplicates


def run_preprocessing(dataset):

    print()

    print("=" * 60)

    print("Preprocessing Pipeline")

    print("=" * 60)

    # ----------------------------------------
    # Verify Dataset
    # ----------------------------------------

    verify_dataset(dataset)

    # ----------------------------------------
    # Check Duplicates
    # ----------------------------------------

    duplicates = check_duplicates(dataset)

    print()

    print("=" * 60)

    print("Summary")

    print("=" * 60)

    print("Duplicates :", len(duplicates))

    print("=" * 60)

    # ----------------------------------------
    # Create Clean Dataset
    # ----------------------------------------

    clean_dataset = remove_duplicates(dataset)

    print()

    print("=" * 60)

    print("Using Clean Dataset")

    print("=" * 60)

    print(clean_dataset)

    print("=" * 60)

    return clean_dataset